#!/usr/bin/env python3
"""
Printzo server — print centre, no internet needed.
Serves print-kiosk.html on the shop WiFi so customers can open it from
their phones, upload a PDF, choose options, and pay. The owner approves
jobs from the same page (Owner button, PIN).

Run:  python3 server.py
Then open the printed address (e.g. http://192.168.1.5:8000) in any
browser on the same WiFi. Customers: connect to the shop WiFi first.

Only Python standard library is used. Files are saved in ./jobs/.
"""
import atexit
import hashlib
import json
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

BASE = os.path.dirname(os.path.abspath(__file__))
# The script's own path, captured at import time. __file__ itself is
# NOT reliable later in this process (it has been observed missing
# from the module globals in a long-running server), so the self-update
# restart must use this constant, never __file__ directly.
SCRIPT_PATH = os.path.abspath(__file__)
JOBS_DIR = os.path.join(BASE, "jobs")
JOBS_FILE = os.path.join(BASE, "jobs.json")
CUSTOMERS_FILE = os.path.join(BASE, "customers.json")
SETTINGS_FILE = os.path.join(BASE, "settings.json")
PID_FILE = os.path.join(BASE, "server.pid")
UPDATE_DIR = os.path.join(BASE, "update")
PENDING_FILE = os.path.join(UPDATE_DIR, "update-pending.json")
STATE_FILE = os.path.join(UPDATE_DIR, "update-state.json")
LAST_UPDATE_FILE = os.path.join(UPDATE_DIR, "last-update.json")
# A code update may replace ONLY these two files — never jobs, settings,
# customers, or anything else. Anything else in a code ZIP is refused.
CODE_ALLOWLIST = {"print-kiosk.html", "server.py"}
PORT = 8000

# Current version of this tool. The owner dashboard shows it, and the
# update check compares it against the release channel (updateUrl).
VERSION = "1.4.1"
UPDATE_CHECK_INTERVAL = 6 * 3600  # seconds between release checks

DEFAULT_SETTINGS = {
    "shopName": "Printzo", "upiId": "", "pin": "1234",
    "nextToken": 101, "adText": "", "deleteAfterHours": 24,
    "rates": {"bwA4": 2, "bwLegal": 3, "bwA3": 4, "colA4": 10, "colLegal": 12, "colA3": 15},
    "machine1Name": "Machine 1", "machine2Name": "Machine 2",
    "onlineMachine": 1, "autoPrint": False, "whatsappNumber": "",
    "plan": "trial", "trialStart": "", "trialDays": 7,
    "updateUrl": "https://raw.githubusercontent.com/printzo-app/printzo-releases/main/version.json",
    "historyDays": 15, "setupDone": False, "gstin": "",
    # v1.4.0 — dashboard theme, auto-print wait, ads, bill template/signature,
    # and the real printer each machine maps to (see /api/printers).
    "theme": "light", "autoPrintDelaySeconds": 5,
    "printzoAdText": "Printzo — smart printing for your shop · printzoapp@gmail.com",
    "billTemplateHtml": "", "billSignature": "",
    "machine1Printer": "", "machine2Printer": "",
    # v1.4.1 — shop Gmail ID (customer contact card) and how each machine
    # is connected: "usb" / "lan" / "wifi" (+ IP for network machines).
    "shopEmail": "",
    "machine1Conn": "usb", "machine1Ip": "",
    "machine2Conn": "usb", "machine2Ip": "",
}
PROFILE_FILE = os.path.join(BASE, "profile.json")

os.makedirs(JOBS_DIR, exist_ok=True)
LOCK = threading.Lock()

# ---- silent self-update (release channel) ----
# The shop PC checks updateUrl (a small version.json) on startup and
# every 6 hours. If the shop has no internet, the check just fails
# silently and the tool keeps working — it never blocks or nags.
#
# version.json must look like:
#   {"version": "1.3.0",
#    "download_url": "https://.../Printzo-Setup.exe",   # full installer (fallback)
#    "code_url": "https://.../Printzo-Code-1.4.1.zip",  # ONLY print-kiosk.html + server.py
#    "code_sha256": "<hex sha256 of the code zip>",
#    "notes": "..."}
#
# How it works (Instagram-style — no owner action needed):
#   1. A newer version with code_url is found -> the small code ZIP is
#      downloaded in the background and its SHA-256 is verified.
#   2. The next time the tool starts (or the owner taps "Update now"),
#      the new code is applied: the current files are backed up, ONLY
#      print-kiosk.html + server.py are replaced (jobs, settings,
#      customers and data are never touched), and a new server process
#      is started. If the new process does not answer within 10
#      seconds, the backup is restored and the old version serves
#      again — the shop is never left without a working tool.
#   3. If the code path fails twice for a version, that version is
#      marked failed and the dashboard falls back to the full-installer
#      update (the old v1.1.0 button).
update_info = {"latest": None, "download_url": "", "code_url": "",
               "code_sha256": "", "notes": ""}
update_info_lock = threading.Lock()
code_download_lock = threading.Lock()
code_download_running = False
SERVER = None  # the running ThreadingHTTPServer (for the update-now flow)


def compare_versions(a, b):
    """Compare dotted versions numerically. Returns 1 if a > b, -1 if a < b, else 0."""
    def parts(v):
        out = []
        for p in str(v).split("."):
            try:
                out.append(int(p))
            except ValueError:
                out.append(0)
        return out
    pa, pb = parts(a), parts(b)
    n = max(len(pa), len(pb))
    pa += [0] * (n - len(pa))
    pb += [0] * (n - len(pb))
    return (pa > pb) - (pa < pb)


def _update_state():
    """Persistent self-update state: {"failed_versions": [...],
    "code_failures": {"1.3.1": 1}} — lives in BASE/update/."""
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return {"failed_versions": list(data.get("failed_versions", [])),
                    "code_failures": dict(data.get("code_failures", {}))}
    except (OSError, ValueError):
        pass
    return {"failed_versions": [], "code_failures": {}}


def _save_update_state(state):
    try:
        os.makedirs(UPDATE_DIR, exist_ok=True)
        save_json(STATE_FILE, state)
    except OSError:
        pass


def _code_failed(version):
    st = _update_state()
    return version in st["failed_versions"] or st["code_failures"].get(version, 0) >= 2


def _record_code_failure(version, fatal=False):
    """Record a failed code update. Download/SHA failures get two
    strikes (the network may just be flaky); a health-check failure
    (fatal=True) means the code itself is broken, so the identical
    ZIP would fail again — block it at once so it is never re-offered
    or re-applied on the next start."""
    st = _update_state()
    st["code_failures"][version] = st["code_failures"].get(version, 0) + 1
    if (fatal or st["code_failures"][version] >= 2) and version not in st["failed_versions"]:
        st["failed_versions"].append(version)
    _save_update_state(st)


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _code_zip_ok(zip_path, expected_sha):
    """A code ZIP is valid only if the SHA-256 matches AND it contains
    EXACTLY print-kiosk.html + server.py — nothing else, no folders,
    no '..', no absolute paths. Anything else is refused outright."""
    try:
        if expected_sha and _sha256_file(zip_path) != expected_sha.lower():
            return False
        with zipfile.ZipFile(zip_path) as zf:
            names = zf.namelist()
        if sorted(names) != sorted(CODE_ALLOWLIST):
            return False
        return True
    except Exception:
        return False


def _load_pending_marker():
    try:
        with open(PENDING_FILE, encoding="utf-8") as f:
            m = json.load(f)
        if isinstance(m, dict) and m.get("version") and m.get("zip_path"):
            return m
    except (OSError, ValueError):
        pass
    return None


def _save_pending_marker(version, zip_path, sha256):
    try:
        os.makedirs(UPDATE_DIR, exist_ok=True)
        save_json(PENDING_FILE, {"version": version, "zip_path": zip_path, "sha256": sha256})
    except OSError:
        pass


def _clear_pending_marker():
    try:
        os.remove(PENDING_FILE)
    except OSError:
        pass


def _pending_is_valid(marker):
    """True only if the pending update is newer, not failed, and the ZIP
    on disk is intact. Anything else: do not apply."""
    try:
        version = str(marker["version"])
        if compare_versions(version, VERSION) <= 0:
            return False
        if _code_failed(version):
            return False
        zip_path = marker["zip_path"]
        if not os.path.isfile(zip_path):
            return False
        return _code_zip_ok(zip_path, marker.get("sha256", ""))
    except Exception:
        return False


def download_code_update(latest, code_url, sha256):
    """Download the small code ZIP in the background. Silent on any
    failure — the installer fallback stays available."""
    global code_download_running
    with code_download_lock:
        if code_download_running:
            return
        code_download_running = True
    try:
        if _code_failed(latest):
            return
        os.makedirs(UPDATE_DIR, exist_ok=True)
        dest = os.path.join(UPDATE_DIR, "code-%s.zip" % latest)
        if os.path.isfile(dest) and _code_zip_ok(dest, sha256):
            _save_pending_marker(latest, dest, sha256)
            return
        tmp = dest + ".tmp"
        req = urllib.request.Request(code_url, headers={"User-Agent": "Printzo/" + VERSION})
        with urllib.request.urlopen(req, timeout=30) as resp, open(tmp, "wb") as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                f.write(chunk)
        os.replace(tmp, dest)
        if _code_zip_ok(dest, sha256):
            _save_pending_marker(latest, dest, sha256)
        else:
            try:
                os.remove(dest)
            except OSError:
                pass
            _record_code_failure(latest)
    except Exception:
        try:
            os.remove(os.path.join(UPDATE_DIR, "code-%s.zip.tmp" % latest))
        except OSError:
            pass
        _record_code_failure(latest)
    finally:
        with code_download_lock:
            code_download_running = False


def _log_update(msg):
    try:
        os.makedirs(UPDATE_DIR, exist_ok=True)
        with open(os.path.join(UPDATE_DIR, "update.log"), "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except OSError:
        pass


def _spawn_server():
    """Start a new server process (same command line) detached, with
    its output going to update/update.log. Returns the Popen object."""
    os.makedirs(UPDATE_DIR, exist_ok=True)
    log_path = os.path.join(UPDATE_DIR, "update.log")
    log = open(log_path, "ab")
    try:
        proc = subprocess.Popen(
            [sys.executable, SCRIPT_PATH] + sys.argv[1:],
            stdin=subprocess.DEVNULL, stdout=log, stderr=log,
            start_new_session=True, close_fds=True)
    finally:
        log.close()
    return proc


def _wait_for_server(timeout=10):
    """Poll http://127.0.0.1:8000/ until it answers 200 (or timeout)."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen("http://127.0.0.1:8000/", timeout=1) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def _stop_proc(proc, timeout=3):
    try:
        proc.terminate()
        proc.wait(timeout=timeout)
    except Exception:
        try:
            proc.kill()
            proc.wait(timeout=timeout)
        except Exception:
            pass


def _backup_current():
    """Copy the two code files aside before an update. Returns the
    backup directory (older backups are removed first)."""
    for name in os.listdir(UPDATE_DIR):
        if name.startswith("backup-"):
            try:
                shutil.rmtree(os.path.join(UPDATE_DIR, name))
            except OSError:
                pass
    bdir = os.path.join(UPDATE_DIR, "backup-" + VERSION)
    os.makedirs(bdir, exist_ok=True)
    for fname in CODE_ALLOWLIST:
        shutil.copy2(os.path.join(BASE, fname), os.path.join(bdir, fname))
    return bdir


def _restore_backup(bdir):
    for fname in CODE_ALLOWLIST:
        src = os.path.join(bdir, fname)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(BASE, fname))


def _extract_code_zip(zip_path):
    """Replace ONLY print-kiosk.html + server.py from a verified ZIP.
    The ZIP was already checked by _code_zip_ok — this is the second
    gate, and it refuses anything unexpected."""
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        if sorted(names) != sorted(CODE_ALLOWLIST):
            raise ValueError("unexpected files in code zip: %r" % names)
        for name in names:
            data = zf.read(name)
            with open(os.path.join(BASE, name), "wb") as f:
                f.write(data)


def perform_update_flow(marker):
    """Apply a pending code update: backup, extract, start the new
    server, health-check it, roll back if it does not answer.
    Returns True if a spawned process is now serving (new version, or
    the rolled-back old version) — the caller should then exit.
    Returns False if no spawned process is serving — the caller should
    keep serving in this process (startup path) or give up (the
    update-now path: files on disk are the good old version, the
    owner restarts via the Desktop icon)."""
    version = str(marker["version"])
    zip_path = marker["zip_path"]
    if not _pending_is_valid(marker):
        _clear_pending_marker()
        return False
    try:
        bdir = _backup_current()
    except Exception as e:
        _log_update("update %s: backup failed: %s" % (version, e))
        return False
    try:
        _extract_code_zip(zip_path)
    except Exception as e:
        _log_update("update %s: extract failed: %s — restoring backup" % (version, e))
        try:
            _restore_backup(bdir)
        except Exception:
            pass
        _clear_pending_marker()
        _record_code_failure(version)
        return False
    _clear_pending_marker()
    _log_update("update %s: code applied, starting new server" % version)
    try:
        proc = _spawn_server()
    except Exception as e:
        _log_update("update %s: spawn failed: %s — restoring backup" % (version, e))
        try:
            _restore_backup(bdir)
        except Exception:
            pass
        return False
    if _wait_for_server(timeout=10):
        _log_update("update %s: new server healthy" % version)
        try:
            save_json(LAST_UPDATE_FILE, {"version": version, "applied_at": int(time.time() * 1000)})
        except OSError:
            pass
        return True
    # New server did not answer — roll back to the backup and serve
    # the old version again. The shop is never left without a tool.
    _log_update("update %s: new server did NOT answer — rolling back" % version)
    _stop_proc(proc)
    try:
        _restore_backup(bdir)
    except Exception as e:
        _log_update("update %s: rollback restore failed: %s" % (version, e))
        return False
    # The new code itself is broken (e.g. a syntax error) — retrying
    # the identical ZIP would fail the same way, so block this version
    # at once instead of re-offering it on the next start.
    _record_code_failure(version, fatal=True)
    try:
        proc2 = _spawn_server()
    except Exception as e:
        _log_update("update %s: rollback spawn failed: %s" % (version, e))
        return False
    if _wait_for_server(timeout=10):
        _log_update("update %s: rolled back, old server healthy" % version)
        return True
    _log_update("update %s: rolled-back server also did not answer" % version)
    _stop_proc(proc2)
    return False


def do_update_now():
    """Runs in its own thread after POST /api/apply-update: stop this
    server, apply the pending code update, and let the main thread
    exit once a spawned process is serving. This is a non-daemon
    thread, so the process stays alive until it finishes; atexit
    remove_pid is unregistered first so the new process keeps its
    own PID file."""
    time.sleep(1)  # let the HTTP response flush first
    try:
        atexit.unregister(remove_pid)
    except Exception:
        pass
    global SERVER
    try:
        if SERVER is not None:
            SERVER.shutdown()
            SERVER.server_close()
    except Exception:
        pass
    marker = _load_pending_marker()
    if marker and _pending_is_valid(marker):
        perform_update_flow(marker)


def fetch_update_info():
    """Fetch the release channel once. Never raises: offline, a 404, or
    bad data just means 'no update known' — the last good result stays."""
    try:
        settings = get_settings()
        url = (settings.get("updateUrl") or "").strip()
        if not url:
            return
        req = urllib.request.Request(url, headers={"User-Agent": "Printzo/" + VERSION})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        latest = str(data.get("version", "") or "").strip()
        if not latest:
            return
        with update_info_lock:
            update_info.update({
                "latest": latest,
                "download_url": str(data.get("download_url", "") or ""),
                "code_url": str(data.get("code_url", "") or ""),
                "code_sha256": str(data.get("code_sha256", "") or ""),
                "notes": str(data.get("notes", "") or ""),
            })
        # A newer version with a code ZIP: fetch it in the background
        # so it is ready before the owner ever has to think about it.
        if compare_versions(latest, VERSION) > 0:
            code_url = str(data.get("code_url", "") or "").strip()
            sha256 = str(data.get("code_sha256", "") or "").strip()
            if code_url and sha256:
                threading.Thread(
                    target=download_code_update, args=(latest, code_url, sha256),
                    daemon=True).start()
    except Exception:
        pass


def update_check_loop():
    fetch_update_info()
    while True:
        time.sleep(UPDATE_CHECK_INTERVAL)
        fetch_update_info()


def write_pid():
    """Record our process id so the installer can stop an old copy first."""
    try:
        with open(PID_FILE, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except OSError:
        pass


def remove_pid():
    try:
        os.remove(PID_FILE)
    except OSError:
        pass


def load_json(path, fallback):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(fallback, dict):
            merged = dict(fallback)
            merged.update(data)
            return merged
        return data
    except (OSError, ValueError):
        return fallback


def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def get_jobs():
    return load_json(JOBS_FILE, [])


def save_jobs(jobs):
    save_json(JOBS_FILE, jobs)


def get_customers():
    return load_json(CUSTOMERS_FILE, [])


def save_customers(customers):
    save_json(CUSTOMERS_FILE, customers)


def next_customer_id(customers):
    """Sequential customer id, CUST-001, CUST-002, ... — never reused,
    even if a customer is deleted later."""
    n = 0
    for c in customers:
        m = re.match(r"^CUST-(\d+)$", str(c.get("id", "")))
        if m:
            n = max(n, int(m.group(1)))
    return "CUST-%03d" % (n + 1)


def customer_totals(cid, jobs):
    """(total billed, total paid, balance due) for one customer."""
    billed = sum(j.get("total", 0) or 0 for j in jobs if j.get("customerId") == cid)
    paid = sum(j.get("total", 0) or 0 for j in jobs if j.get("customerId") == cid and j.get("paid"))
    return billed, paid, billed - paid


def get_settings():
    return load_json(SETTINGS_FILE, DEFAULT_SETTINGS)


# ---- v1.4.0: local shop profile (signup / login, offline) ----
# The profile lives on the shop PC only (profile.json). The password is
# stored as a SHA-256 hash, never in plain text. There is NO OTP here:
# sending an OTP SMS needs a paid gateway + internet, so phone
# verification is labelled "coming in the hosted version" in the UI
# and is never faked.
def get_profile():
    try:
        with open(PROFILE_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def save_profile(profile):
    save_json(PROFILE_FILE, profile)


def public_profile(profile):
    if not profile:
        return None
    return {"phone": profile.get("phone", ""), "shopName": profile.get("shopName", ""),
            "shopAddress": profile.get("shopAddress", ""),
            "whatsappNumber": profile.get("whatsappNumber", ""),
            "shopEmail": profile.get("shopEmail", ""),
            "createdAt": profile.get("createdAt", 0)}


def list_printers():
    """The shop PC's REAL printers (Windows: PowerShell Get-Printer).
    On any other OS, or when PowerShell fails, returns ok=False so the
    UI falls back to typed printer names — the list is never invented."""
    if os.name != "nt":
        return {"ok": False, "printers": [],
                "error": "Printer list works on the shop's Windows PC only — type the printer name below."}
    try:
        ps = ("Get-Printer | Select-Object Name, DriverName, PortName, "
              "Shared | ConvertTo-Json -Compress")
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                             capture_output=True, text=True, timeout=15)
        if out.returncode != 0 or not out.stdout.strip():
            return {"ok": False, "printers": [], "error": "Could not list printers — type the printer name below."}
        data = json.loads(out.stdout)
        if isinstance(data, dict):
            data = [data]
        printers = [{"name": str(p.get("Name", "")), "driver": str(p.get("DriverName", "")),
                     "port": str(p.get("PortName", ""))}
                    for p in data if isinstance(p, dict) and p.get("Name")]
        return {"ok": True, "printers": printers, "error": ""}
    except Exception as e:
        return {"ok": False, "printers": [], "error": "Could not list printers (%s) — type the printer name below." % e}


# ---- v1.4.1: machine health (SNMP for network printers, Windows Bidi for USB) ----
# How a machine is read depends on how it is connected — the shop's
# Select Devices entry records USB / LAN / WiFi (+ IP for network ones):
#   * LAN / WiFi: SNMP (Printer MIB, RFC 3805) over UDP. Xerox
#     WorkCentre-type machines answer this: toner % per colour,
#     lifetime page count, status and error flags. Pure Python, no
#     new dependencies — the bundle stays small and offline-first.
#   * USB: the Windows spooler + the printer driver's two-way
#     channel (Bidi, \Printer.Consumables). Status always; toner %
#     ONLY when that machine/driver reports it — there is no universal
#     ink-level method on Windows, it depends on model + driver.
#     This code is Windows-only and UNTESTED on Windows; every call
#     is wrapped so a failure just means "unknown", never a crash.
# HONESTY RULE: a value the machine does not report is shown as
# "unknown" — never a guessed or fake number. The app's own job
# counts always work for every machine.
SNMP_COMMUNITY = "public"
SNMP_TIMEOUT = 1.0  # LAN printers answer in milliseconds; 1 s is plenty
OID_SUPPLIES = "1.3.6.1.2.1.43.11.1.1"
OID_LIFE_COUNT = "1.3.6.1.2.1.43.10.2.1.4.1"
OID_LIFE_COUNT_XEROX = "1.3.6.1.4.1.253.8.53.13.2.1.6.1.20.1"
OID_HR_STATUS = "1.3.6.1.2.1.25.3.5.1.1.1"
OID_HR_ERROR = "1.3.6.1.2.1.25.3.5.1.2.1"
HR_STATUS_NAMES = {1: "other", 2: "unknown", 3: "idle", 4: "printing", 5: "warmup"}
HR_ERROR_BITS = ["Low paper", "No paper", "Low toner", "No toner",
                 "Door open", "Paper jam", "Offline", "Service requested"]
HEALTH_FILE = os.path.join(BASE, "machine_health.json")
HEALTH_POLL_SECONDS = 60
health_lock = threading.Lock()


def _ber_len(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _ber_tlv(tag, content):
    return bytes([tag]) + _ber_len(len(content)) + content


def _ber_int_bytes(n):
    """DER encoding of an INTEGER (handles negative values too)."""
    if n == 0:
        return b"\x00"
    ln = (n.bit_length() + 8) // 8
    b = n.to_bytes(ln, "big", signed=True)
    if n > 0 and b[0] & 0x80:
        b = b"\x00" + b
    return b


def _ber_encode_oid(oid_str):
    parts = [int(p) for p in oid_str.split(".")]
    out = bytes([parts[0] * 40 + parts[1]])
    for p in parts[2:]:
        enc = bytearray([p & 0x7F])
        p >>= 7
        while p:
            enc.append(0x80 | (p & 0x7F))
            p >>= 7
        out += bytes(reversed(enc))
    return _ber_tlv(0x06, out)


def _ber_read(data, pos):
    """Read one TLV at pos. Returns (tag, content, next_pos)."""
    if pos >= len(data):
        raise ValueError("short ber")
    tag = data[pos]
    pos += 1
    if pos >= len(data):
        raise ValueError("short ber")
    ln = data[pos]
    pos += 1
    if ln & 0x80:
        n = ln & 0x7F
        if n == 0 or pos + n > len(data):
            raise ValueError("bad ber length")
        ln = int.from_bytes(data[pos:pos + n], "big")
        pos += n
    if pos + ln > len(data):
        raise ValueError("short ber")
    return tag, data[pos:pos + ln], pos + ln


def _ber_decode_oid(raw):
    if not raw:
        return ""
    parts = [raw[0] // 40, raw[0] % 40]
    val = 0
    for b in raw[1:]:
        val = (val << 7) | (b & 0x7F)
        if not (b & 0x80):
            parts.append(val)
            val = 0
    return ".".join(str(p) for p in parts)


def _ber_decode_value(tag, raw):
    if tag == 0x02:  # INTEGER
        return int.from_bytes(raw, "big", signed=True) if raw else 0
    if tag in (0x41, 0x42, 0x43):  # Counter32, Gauge32, TimeTicks
        return int.from_bytes(raw, "big") if raw else 0
    if tag == 0x04:  # OCTET STRING
        try:
            return raw.decode("utf-8", "replace").rstrip("\x00")
        except Exception:
            return raw.hex()
    if tag == 0x06:  # OBJECT IDENTIFIER
        return _ber_decode_oid(raw)
    if tag == 0x40:  # IpAddress
        return ".".join(str(b) for b in raw) if len(raw) == 4 else raw.hex()
    return None  # NULL, noSuchObject, noSuchInstance, endOfMibView


def _snmp_request(ip, port, pdu_tag, oids, community=SNMP_COMMUNITY, timeout=SNMP_TIMEOUT):
    """One SNMPv2c request (GET 0xA0 or GETNEXT 0xA1). Returns a list of
    (oid_str, tag, value) varbinds, or None on timeout / bad reply."""
    req_id = int(time.time() * 1000) & 0x7FFFFFFF
    varbinds = b"".join(
        _ber_tlv(0x30, _ber_encode_oid(o) + _ber_tlv(0x05, b"")) for o in oids)
    pdu = _ber_tlv(pdu_tag,
                   _ber_tlv(0x02, _ber_int_bytes(req_id)) +
                   _ber_tlv(0x02, b"\x00") + _ber_tlv(0x02, b"\x00") +
                   _ber_tlv(0x30, varbinds))
    msg = _ber_tlv(0x30,
                   _ber_tlv(0x02, _ber_int_bytes(1)) +
                   _ber_tlv(0x04, community.encode("ascii", "replace")) + pdu)
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        try:
            sock.sendto(msg, (ip, port))
            data, _addr = sock.recvfrom(65535)
        finally:
            sock.close()
    except (OSError, socket.timeout):
        return None
    try:
        _tag, msg_body, _pos = _ber_read(data, 0)
        _t, _ver, p = _ber_read(msg_body, 0)
        _t, _comm, p = _ber_read(msg_body, p)
        pdu_tag_r, pdu_body, _p = _ber_read(msg_body, p)
        _t, _rid, q = _ber_read(pdu_body, 0)
        _t, err_status, q = _ber_read(pdu_body, q)
        _t, _err_idx, q = _ber_read(pdu_body, q)
        if _ber_decode_value(0x02, err_status) != 0:
            return None
        _t, vb_list, _q = _ber_read(pdu_body, q)
        out = []
        pos = 0
        while pos < len(vb_list):
            _t, vb, pos = _ber_read(vb_list, pos)
            _t, oid_raw, p2 = _ber_read(vb, 0)
            vtag, val_raw, _p2 = _ber_read(vb, p2)
            out.append((_ber_decode_oid(oid_raw), vtag, _ber_decode_value(vtag, val_raw)))
        return out
    except Exception:
        return None


def _snmp_get(ip, port, oid, timeout=SNMP_TIMEOUT):
    res = _snmp_request(ip, port, 0xA0, [oid], timeout=timeout)
    if not res:
        return None
    o, tag, val = res[0]
    if tag in (0x80, 0x81, 0x82) or o != oid:
        return None
    return val


def _snmp_walk(ip, port, base_oid, max_rows=80, deadline_s=4.0):
    """GETNEXT walk of one subtree. Returns {oid: (tag, value)}."""
    out = {}
    cur = base_oid
    deadline = time.time() + deadline_s
    while len(out) < max_rows and time.time() < deadline:
        res = _snmp_request(ip, port, 0xA1, [cur],
                            timeout=min(SNMP_TIMEOUT, max(0.2, deadline - time.time())))
        if not res:
            break
        oid, tag, val = res[0]
        if tag == 0x82 or not oid.startswith(base_oid + "."):
            break
        out[oid] = (tag, val)
        cur = oid
    return out


def _classify_supply(desc, col_type):
    """Map one supplies-table row to a colour ('black'/'cyan'/
    'magenta'/'yellow') or None (not a toner/ink supply)."""
    d = (desc or "").lower()
    if any(w in d for w in ("waste", "drum", "fuser", "transfer", "roller",
                            "maintenance", "cleaner", "belt", "imaging unit")):
        return None
    if col_type == 4:  # wasteToner
        return None
    for color in ("black", "cyan", "magenta", "yellow"):
        if color in d:
            return color
    if col_type in (3, 5) or "toner" in d or "ink" in d or "cartridge" in d:
        return "black"  # monochrome cartridge, or colour word missing
    return None


def snmp_poll_machine(ip, port=161):
    """Poll one network printer over SNMP. Returns a dict with
    ok / toner {colour: pct-or-None} / pageCount / status / errors /
    error. Never raises; a machine that does not answer is ok=False."""
    result = {"ok": False, "toner": {}, "pageCount": None,
              "status": "unknown", "errors": [], "error": ""}
    try:
        # Supplies table: group rows by (device index, supplies index).
        walked = _snmp_walk(ip, port, OID_SUPPLIES)
        rows = {}
        base_parts = len(OID_SUPPLIES.split("."))
        for oid, (_tag, val) in walked.items():
            parts = oid.split(".")
            if len(parts) < base_parts + 3:
                continue
            col = int(parts[base_parts])
            idx = (parts[base_parts + 1], parts[base_parts + 2])
            rows.setdefault(idx, {})[col] = val
        toner = {}
        for idx in sorted(rows):
            r = rows[idx]
            desc = r.get(5, "")
            col_type = r.get(4)
            color = _classify_supply(str(desc) if desc is not None else "", col_type)
            if not color:
                continue
            level = r.get(8)
            cap = r.get(7)
            if level is None and 9 in r:  # some agents number level .9
                level, cap = r.get(9), r.get(8)
            pct = None
            if (isinstance(level, int) and isinstance(cap, int)
                    and level >= 0 and cap > 0):
                pct = round(level * 100.0 / cap)
                if pct < 0 or pct > 100:
                    pct = None  # odd value (e.g. 600%) — treat as unknown
            if color not in toner or toner[color] is None:
                toner[color] = pct
        result["toner"] = toner
        # Lifetime page count (standard OID, Xerox OID as fallback).
        pc = _snmp_get(ip, port, OID_LIFE_COUNT)
        if not isinstance(pc, int) or pc < 0:
            pc = _snmp_get(ip, port, OID_LIFE_COUNT_XEROX)
        if isinstance(pc, int) and pc >= 0:
            result["pageCount"] = pc
        # Status + error flags.
        st = _snmp_get(ip, port, OID_HR_STATUS)
        if isinstance(st, int):
            result["status"] = HR_STATUS_NAMES.get(st, "other")
        err_raw = _snmp_get(ip, port, OID_HR_ERROR)
        if isinstance(err_raw, str):
            raw = err_raw.encode("utf-8", "replace")
        elif isinstance(err_raw, bytes):
            raw = err_raw
        else:
            raw = b""
        if raw:
            bits = raw[0]
            result["errors"] = [HR_ERROR_BITS[i] for i in range(8)
                                if bits & (1 << i)]
        answered = bool(walked) or result["pageCount"] is not None or \
            result["status"] != "unknown"
        if not answered:
            result["error"] = "Printer did not answer SNMP — check the IP and that SNMP is on."
            return result
        result["ok"] = True
        return result
    except Exception as e:
        result["error"] = "SNMP poll failed: %s" % e
        return result


def _usb_status_windows(printer_name):
    """Windows spooler status bits for one local printer. Returns
    (status_str, errors_list, toner_low_bool) or (None, [], False)
    when it cannot be read. Windows-only."""
    try:
        import ctypes
        from ctypes import wintypes
        winspool = ctypes.windll.winspool
        handle = wintypes.HANDLE()
        if not winspool.OpenPrinterW(printer_name, ctypes.byref(handle), None):
            return None, [], False
        try:
            size = wintypes.DWORD(0)
            winspool.GetPrinterW(handle, 2, None, 0, ctypes.byref(size))
            if size.value <= 0:
                return None, [], False
            buf = ctypes.create_string_buffer(size.value)
            if not winspool.GetPrinterW(handle, 2, buf, size, ctypes.byref(size)):
                return None, [], False
            # PRINTER_INFO_2 (64-bit): 13 pointers, then Attributes,
            # Priority, DefaultPriority, StartTime, UntilTime, Status.
            status = int.from_bytes(buf.raw[124:128], "little")
        finally:
            winspool.ClosePrinter(handle)
    except Exception:
        return None, [], False
    errors = []
    if status & 0x00000008:
        errors.append("Paper jam")
    if status & 0x00000010:
        errors.append("No paper")
    if status & 0x00020000:
        errors.append("Low toner")
    if status & 0x00040000:
        errors.append("No toner")
    if status & 0x00400000:
        errors.append("Door open")
    if status & 0x00100000:
        errors.append("Needs attention")
    if status & 0x00000002:
        errors.append("Printer error")
    if status & 0x00000080 or status & 0x00001000:
        state = "offline"
    elif status & 0x00000400 or status & 0x00000200:
        state = "printing"
    elif status & 0x00010000:
        state = "warmup"
    elif status & 0x00000001:
        state = "paused"
    else:
        state = "idle"
    return state, errors, bool(status & 0x00060000)


def _bidi_consumables_windows(printer_name):
    """Best-effort toner % over the Windows Bidi channel
    (\\Printer.Consumables). Returns {colour: pct} or None.
    UNTESTED on Windows — any failure just means 'unknown'."""
    try:
        import ctypes
        from ctypes import wintypes

        class _BidiDataUnion(ctypes.Union):
            _fields_ = [("bData", wintypes.BOOL), ("iData", wintypes.LONG),
                        ("sData", wintypes.LPWSTR), ("fData", ctypes.c_float)]

        class _BidiData(ctypes.Structure):
            _fields_ = [("dwDataType", wintypes.DWORD), ("u", _BidiDataUnion)]

        class _BidiRequestData(ctypes.Structure):
            _fields_ = [("dwReqNumber", wintypes.DWORD),
                        ("pszSchema", wintypes.LPWSTR),
                        ("data", _BidiData)]

        class _BidiRequestContainer(ctypes.Structure):
            _fields_ = [("Version", wintypes.DWORD), ("Flags", wintypes.DWORD),
                        ("Count", wintypes.DWORD),
                        ("aData", _BidiRequestData * 1)]

        class _BidiResponseData(ctypes.Structure):
            _fields_ = [("dwResult", wintypes.DWORD),
                        ("pszSchema", wintypes.LPWSTR),
                        ("data", _BidiData)]

        class _BidiResponseContainer(ctypes.Structure):
            _fields_ = [("Version", wintypes.DWORD), ("Flags", wintypes.DWORD),
                        ("Count", wintypes.DWORD),
                        ("aData", _BidiResponseData * 1)]

        winspool = ctypes.windll.winspool
        handle = wintypes.HANDLE()
        if not winspool.OpenPrinterW(printer_name, ctypes.byref(handle), None):
            return None
        try:
            req = _BidiRequestContainer()
            req.Version = 1
            req.Flags = 0
            req.Count = 1
            req.aData[0].dwReqNumber = 0
            req.aData[0].pszSchema = "\\Printer.Consumables"
            req.aData[0].data.dwDataType = 0  # BIDI_NULL — a query
            resp_ptr = ctypes.POINTER(_BidiResponseContainer)()
            rc = winspool.SendRecvBidiDataFromPort(
                handle, "\\Printer.Consumables",
                ctypes.byref(req), ctypes.byref(resp_ptr))
            if rc != 0 or not resp_ptr:
                return None
            try:
                resp = resp_ptr.contents
                if resp.Count < 1:
                    return None
                text = resp.aData[0].data.u.sData or ""
            finally:
                try:
                    winspool.FreeBidiResponseContainer(ctypes.byref(resp_ptr))
                except Exception:
                    pass
        finally:
            winspool.ClosePrinter(handle)
        if not text:
            return None
        toner = {}
        for color in ("black", "cyan", "magenta", "yellow"):
            m = re.search(color + r"[^<>]{0,200}?Level[^0-9]{0,10}(\d+)",
                          text, re.IGNORECASE)
            if m:
                pct = int(m.group(1))
                toner[color] = pct if 0 <= pct <= 100 else None
        if not toner:
            levels = re.findall(r"Level[^0-9]{0,10}(\d+)", text, re.IGNORECASE)
            if len(levels) == 1:
                pct = int(levels[0])
                toner["black"] = pct if 0 <= pct <= 100 else None
        return toner or None
    except Exception:
        return None


def usb_poll_machine(printer_name):
    """Poll one USB (or any local) printer via Windows. Returns a dict
    like snmp_poll_machine but without a page count — USB gives no
    lifetime counter, so prints deltas come from the app's own jobs."""
    result = {"ok": False, "toner": {}, "pageCount": None,
              "status": "unknown", "errors": [], "error": ""}
    if os.name != "nt":
        result["error"] = "USB health needs the shop's Windows PC — this PC cannot read USB printers."
        return result
    if not printer_name:
        result["error"] = "No printer selected — pick one in Select Devices."
        return result
    status, errors, toner_low = _usb_status_windows(printer_name)
    if status is None:
        result["error"] = "Windows could not read this printer — check it is switched on and connected."
        return result
    result["ok"] = True
    result["status"] = status
    result["errors"] = errors
    toner = _bidi_consumables_windows(printer_name)
    if toner:
        result["toner"] = toner
    if toner_low and "Low toner" not in errors and "No toner" not in errors:
        result["errors"] = errors + ["Low toner"]
    return result


def _machine_health_default():
    return {"name": "", "printer": "", "conn": "usb", "ip": "",
            "lastPoll": 0, "ok": False, "status": "unknown", "errors": [],
            "toner": {}, "pageCount": None, "printsLastMinute": None,
            "printsLastHour": None, "printsToday": None,
            "printsThisWeek": None, "lowToner": False, "error": "",
            "samples": []}


def _health_load():
    try:
        with open(HEALTH_FILE, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            out = {"machines": {}, "daily": {}}
            if isinstance(data.get("machines"), dict):
                for k, v in data["machines"].items():
                    if isinstance(v, dict):
                        m = _machine_health_default()
                        m.update(v)
                        out["machines"][k] = m
            if isinstance(data.get("daily"), dict):
                out["daily"] = data["daily"]
            return out
    except (OSError, ValueError):
        pass
    return {"machines": {}, "daily": {}}


def _health_save(health):
    try:
        save_json(HEALTH_FILE, health)
    except OSError:
        pass


def _parse_host_port(raw):
    """'192.168.1.20' or '192.168.1.20:161' -> (host, port)."""
    raw = (raw or "").strip()
    if not raw:
        return "", 161
    if ":" in raw:
        host, _, port = raw.rpartition(":")
        try:
            return host.strip(), int(port)
        except ValueError:
            return host.strip(), 161
    return raw, 161


def _record_page_count(m, health, n, now_ms, prev_pc, prev_poll):
    """Update prints deltas + daily totals from a fresh page count."""
    pc = m.get("pageCount")
    if not isinstance(pc, int) or pc < 0:
        m["printsLastMinute"] = None
        m["printsLastHour"] = None
        m["printsToday"] = None
        m["printsThisWeek"] = None
        return
    # Prints since the previous poll (~1 minute apart).
    if (isinstance(prev_pc, int) and prev_pc >= 0 and prev_poll
            and 20000 <= now_ms - prev_poll <= 600000 and pc >= prev_pc):
        m["printsLastMinute"] = pc - prev_pc
    else:
        m["printsLastMinute"] = None
    # One sample per poll, kept for 2 hours, for the last-hour delta.
    black = m.get("toner") or {}
    samples = [s for s in (m.get("samples") or [])
               if isinstance(s, list) and len(s) >= 2
               and now_ms - s[0] < 2 * 3600 * 1000]
    samples.append([now_ms, pc, black.get("black")])
    m["samples"] = samples[-150:]
    m["printsLastHour"] = None
    for s in samples:
        if now_ms - s[0] >= 50 * 60 * 1000 and isinstance(s[1], int) and pc >= s[1]:
            m["printsLastHour"] = pc - s[1]
            break
    # Daily totals (local day): first vs last page count of the day.
    day = time.strftime("%Y-%m-%d", time.localtime(now_ms / 1000))
    daily = health.setdefault("daily", {})
    for old in [k for k in daily if k < day and k < time.strftime(
            "%Y-%m-%d", time.localtime((now_ms - 14 * 86400 * 1000) / 1000))]:
        del daily[old]
    entry = daily.setdefault(day, {}).setdefault(str(n), {"first": pc, "last": pc})
    entry["last"] = pc
    m["printsToday"] = entry["last"] - entry["first"] \
        if entry["last"] >= entry["first"] else None
    total_week = 0
    have_week = False
    for i in range(7):
        dkey = time.strftime("%Y-%m-%d",
                             time.localtime((now_ms - i * 86400 * 1000) / 1000))
        e = daily.get(dkey, {}).get(str(n))
        if e and e["last"] >= e["first"]:
            total_week += e["last"] - e["first"]
            have_week = True
    m["printsThisWeek"] = total_week if have_week else None
    toner = m.get("toner") or {}
    m["lowToner"] = any(isinstance(v, int) and v < 10 for v in toner.values())


def poll_machine(n):
    """Poll one machine (1 or 2) right now and store the reading.
    Returns the machine's health dict. Never raises."""
    settings = get_settings()
    name = (settings.get("machine%dName" % n) or ("Machine %d" % n)).strip() \
        or ("Machine %d" % n)
    printer = (settings.get("machine%dPrinter" % n) or "").strip()
    conn = (settings.get("machine%dConn" % n) or "usb").strip().lower()
    if conn not in ("usb", "lan", "wifi"):
        conn = "usb"
    ip_raw = (settings.get("machine%dIp" % n) or "").strip()
    host, port = _parse_host_port(ip_raw)
    now_ms = int(time.time() * 1000)
    with health_lock:
        health = _health_load()
        m = health["machines"].setdefault(str(n), _machine_health_default())
        prev_pc = m.get("pageCount")
        prev_poll = m.get("lastPoll") or 0
        m["name"] = name
        m["printer"] = printer
        m["conn"] = conn
        m["ip"] = ip_raw
        if conn in ("lan", "wifi"):
            if not host:
                m.update({"ok": False, "status": "unknown", "errors": [],
                          "toner": {}, "pageCount": None,
                          "error": "No IP set — add the printer's IP in Select Devices (LAN/WiFi machines need it)."})
            else:
                res = snmp_poll_machine(host, port)
                m["ok"] = res["ok"]
                m["status"] = res["status"]
                m["errors"] = res["errors"]
                m["toner"] = res["toner"]
                m["pageCount"] = res["pageCount"]
                m["error"] = res["error"]
                _record_page_count(m, health, n, now_ms, prev_pc, prev_poll)
                if not res["ok"]:
                    m["printsLastMinute"] = None
                    m["printsLastHour"] = None
        else:
            res = usb_poll_machine(printer)
            m["ok"] = res["ok"]
            m["status"] = res["status"]
            m["errors"] = res["errors"]
            m["toner"] = res["toner"]
            m["pageCount"] = None
            m["error"] = res["error"]
            m["printsLastMinute"] = None
            m["printsLastHour"] = None
            m["printsToday"] = None
            m["printsThisWeek"] = None
            toner = m["toner"] or {}
            m["lowToner"] = any(isinstance(v, int) and v < 10 for v in toner.values())
        m["lastPoll"] = now_ms
        _health_save(health)
        return dict(m)


def health_poll_loop():
    """Background: poll each machine about once a minute. Silent on
    any failure — health is a bonus, never a blocker."""
    time.sleep(5)
    while True:
        # The two polls run in parallel — a dead printer must not
        # make the other machine wait.
        threads = [threading.Thread(target=_poll_one, args=(n,), daemon=True)
                   for n in (1, 2)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        time.sleep(HEALTH_POLL_SECONDS)


def _poll_one(n):
    try:
        poll_machine(n)
    except Exception:
        pass


def machine_health_payload():
    """Current health for both machines + the app's own job counts
    (which always work, for every machine)."""
    with health_lock:
        health = _health_load()
        jobs = get_jobs()
    now_ms = int(time.time() * 1000)
    lt = time.localtime(now_ms / 1000)
    day_start = now_ms - (lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec) * 1000 - (now_ms % 1000)
    jobs_today = [j for j in jobs if (j.get("createdAt") or 0) >= day_start]
    machines = {}
    for n in ("1", "2"):
        m = dict(health["machines"].get(n, _machine_health_default()))
        m["samples"] = (m.get("samples") or [])[-24:]
        machines[n] = m
    return {"ok": True, "machines": machines,
            "app": {"jobsToday": len(jobs_today),
                    "printedToday": len([j for j in jobs_today
                                         if j.get("status") in ("printed", "collected")])},
            "updatedAt": now_ms}


def cleanup_old_files():
    """Privacy + history: delete uploaded files older than
    deleteAfterHours, and prune job records older than historyDays
    (unless history is 'forever'). Also sweeps files no job record
    points to any more (e.g. after a manual history clear) once they
    pass deleteAfterHours. Runs forever, checking once a minute.
    The job record itself stays until historyDays passes, so the
    owner keeps the day's accounts (name, token, amount, payment).

    HARD RULE: an UNPAID job (paid=false, any payment mode) is money
    owed — its record is NEVER pruned by retention, however old it
    is. Only paid jobs are pruned. (Files still delete per
    deleteAfterHours — that is the privacy promise — so a credit job
    must be printed within that window, as before.)
    """
    while True:
        try:
            with LOCK:
                settings = get_settings()
                hours = float(settings.get("deleteAfterHours", 24) or 24)
                cutoff = time.time() * 1000 - hours * 3600 * 1000
                jobs = get_jobs()
                changed = False
                for job in jobs:
                    if job.get("stored") and job.get("createdAt", 0) < cutoff:
                        try:
                            os.remove(os.path.join(JOBS_DIR, job["stored"]))
                        except OSError:
                            pass
                        job["stored"] = None
                        job["fileDeleted"] = True
                        changed = True
                # History retention: drop old PAID job records entirely.
                # Unpaid jobs are never pruned — they are money owed.
                hd = settings.get("historyDays", 15)
                if hd != "forever":
                    try:
                        days = int(hd)
                    except (TypeError, ValueError):
                        days = 15
                    if days > 0:
                        hcutoff = time.time() * 1000 - days * 86400 * 1000
                        kept = []
                        for job in jobs:
                            if job.get("createdAt", 0) < hcutoff and job.get("paid"):
                                if job.get("stored"):
                                    try:
                                        os.remove(os.path.join(JOBS_DIR, job["stored"]))
                                    except OSError:
                                        pass
                                changed = True
                            else:
                                kept.append(job)
                        jobs = kept
                # Sweep orphan files (no record references them any more).
                referenced = {j.get("stored") for j in jobs if j.get("stored")}
                for name in os.listdir(JOBS_DIR):
                    if name in referenced:
                        continue
                    fpath = os.path.join(JOBS_DIR, name)
                    try:
                        if os.path.isfile(fpath) and os.path.getmtime(fpath) * 1000 < cutoff:
                            os.remove(fpath)
                    except OSError:
                        pass
                if changed:
                    save_jobs(jobs)
        except Exception:
            pass
        time.sleep(60)


def safe_filename(name):
    name = os.path.basename(name or "file")
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    return name[:120] or "file"


def parse_multipart(body, boundary):
    """Minimal multipart/form-data parser (no external deps)."""
    parts, files = {}, {}
    delim = b"--" + boundary
    for chunk in body.split(delim):
        if not chunk or chunk in (b"--\r\n", b"--", b"\r\n"):
            continue
        if b"\r\n\r\n" not in chunk:
            continue
        head, data = chunk.split(b"\r\n\r\n", 1)
        if data.endswith(b"\r\n"):
            data = data[:-2]
        m = re.search(rb'name="([^"]+)"(?:;\s*filename="([^"]+)")?', head)
        if not m:
            continue
        name = m.group(1).decode("utf-8", "replace")
        fname = m.group(2).decode("utf-8", "replace") if m.group(2) else None
        if fname is not None:
            files[name] = (fname, data)
        else:
            parts[name] = data.decode("utf-8", "replace")
    return parts, files


CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css",
    ".js": "application/javascript",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".pdf": "application/pdf",
    ".json": "application/json",
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # keep the console clean

    def _send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n > 0 else b""

    # ---- GET ----
    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)

        if path == "/api/jobs":
            with LOCK:
                jobs = get_jobs()
            return self._send_json(sorted(jobs, key=lambda j: j.get("createdAt", 0), reverse=True))

        if path == "/api/settings":
            with LOCK:
                out = dict(get_settings())
            # Shop URL for the QR code: the shop PC's WiFi/LAN address,
            # never localhost (a localhost QR cannot open on a customer's phone).
            ips = lan_ips()
            out["shopUrl"] = ("http://%s:%d/" % (ips[0], PORT)) if ips else ""
            return self._send_json(out)

        if path == "/api/customers":
            with LOCK:
                customers = get_customers()
                jobs = get_jobs()
            out = []
            for c in customers:
                billed, paid, pending = customer_totals(c.get("id"), jobs)
                out.append(dict(c, billedTotal=billed, paidTotal=paid, pendingTotal=pending))
            return self._send_json(sorted(out, key=lambda c: c.get("createdAt", 0)))

        if path == "/api/profile":
            return self._send_json({"ok": True, "profile": public_profile(get_profile())})

        if path == "/api/printers":
            return self._send_json(list_printers())

        if path == "/api/machine-health":
            return self._send_json(machine_health_payload())

        if path == "/api/update-check":
            with update_info_lock:
                info = dict(update_info)
            latest = info.get("latest")
            available = bool(latest and compare_versions(latest, VERSION) > 0)
            marker = _load_pending_marker()
            code_ready = bool(available and marker and str(marker.get("version")) == latest
                              and _pending_is_valid(marker))
            just_updated = None
            try:
                with open(LAST_UPDATE_FILE, encoding="utf-8") as f:
                    lu = json.load(f)
                if isinstance(lu, dict) and str(lu.get("version")) == VERSION:
                    just_updated = str(lu.get("version"))
            except (OSError, ValueError):
                pass
            return self._send_json({
                "current": VERSION, "latest": latest,
                "available": available,
                "code_ready": code_ready,
                "code_failed": bool(available and latest and _code_failed(latest)),
                "pending_version": str(marker.get("version")) if marker else None,
                "just_updated": just_updated,
                "download_url": info.get("download_url", ""),
                "notes": info.get("notes", ""),
            })

        if path.startswith("/api/file/"):
            job_id = unquote(path[len("/api/file/"):])
            with LOCK:
                jobs = get_jobs()
            job = next((j for j in jobs if str(j.get("id")) == job_id), None)
            if not job or not job.get("stored"):
                return self._send_json({"ok": False, "error": "not found"}, 404)
            fpath = os.path.join(JOBS_DIR, job["stored"])
            if not os.path.isfile(fpath):
                return self._send_json({"ok": False, "error": "file missing"}, 404)
            ext = os.path.splitext(fpath)[1].lower()
            with open(fpath, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", CONTENT_TYPES.get(ext, "application/octet-stream"))
            self.send_header("Content-Disposition", 'inline; filename="%s"' % job.get("fileName", "file"))
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        # static files (only from this folder)
        fname = "print-kiosk.html" if path in ("/", "/index.html") else path.lstrip("/")
        fpath = os.path.join(BASE, fname)
        if not os.path.isfile(fpath) or os.path.dirname(os.path.abspath(fpath)) != BASE:
            return self._send_json({"ok": False, "error": "not found"}, 404)
        ext = os.path.splitext(fpath)[1].lower()
        with open(fpath, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", CONTENT_TYPES.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # ---- POST ----
    def do_POST(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)

        if path == "/api/profile":
            # Signup: creates the local shop profile. Phone verification
            # (OTP) is NOT done here — see get_profile() note above.
            try:
                data = json.loads(self._read_body().decode("utf-8"))
            except ValueError:
                return self._send_json({"ok": False, "error": "bad json"}, 400)
            phone = re.sub(r"[^0-9]", "", str(data.get("phone") or ""))
            if len(phone) == 10:
                phone = "91" + phone
            if len(phone) != 12 or not phone.startswith("91"):
                return self._send_json({"ok": False, "error": "Enter a valid 10-digit phone number"}, 400)
            password = str(data.get("password") or "")
            if len(password) < 4:
                return self._send_json({"ok": False, "error": "Password must be at least 4 characters"}, 400)
            if password != str(data.get("confirmPassword") or ""):
                return self._send_json({"ok": False, "error": "Passwords do not match"}, 400)
            shop_address = (data.get("shopAddress") or "").strip()
            if not shop_address:
                return self._send_json({"ok": False, "error": "Shop address is required"}, 400)
            whatsapp = re.sub(r"[^0-9]", "", str(data.get("whatsappNumber") or ""))
            if whatsapp and len(whatsapp) not in (10, 12):
                return self._send_json({"ok": False, "error": "WhatsApp number must be 10 digits"}, 400)
            # v1.4.1 — shop Gmail ID (optional; shown on the customer
            # contact card). Validated loosely: must look like an email.
            shop_email = (data.get("shopEmail") or "").strip()
            if shop_email and ("@" not in shop_email or "." not in shop_email.split("@")[-1]):
                return self._send_json({"ok": False, "error": "Enter a valid Gmail ID"}, 400)
            with LOCK:
                profile = {"phone": phone,
                           "passwordHash": hashlib.sha256(password.encode("utf-8")).hexdigest(),
                           "shopName": (data.get("shopName") or "").strip(),
                           "shopAddress": shop_address,
                           "whatsappNumber": whatsapp,
                           "shopEmail": shop_email,
                           "createdAt": int(time.time() * 1000)}
                save_profile(profile)
                # Keep the shop settings in step with the profile.
                settings = get_settings()
                if profile["shopName"]:
                    settings["shopName"] = profile["shopName"]
                if whatsapp:
                    settings["whatsappNumber"] = whatsapp
                if shop_email:
                    settings["shopEmail"] = shop_email
                save_json(SETTINGS_FILE, settings)
            return self._send_json({"ok": True, "profile": public_profile(profile)})

        if path == "/api/login":
            try:
                data = json.loads(self._read_body().decode("utf-8"))
            except ValueError:
                return self._send_json({"ok": False, "error": "bad json"}, 400)
            phone = re.sub(r"[^0-9]", "", str(data.get("phone") or ""))
            if len(phone) == 10:
                phone = "91" + phone
            profile = get_profile()
            if not profile:
                return self._send_json({"ok": False, "error": "No account yet — please sign up first"}, 404)
            if phone != profile.get("phone"):
                return self._send_json({"ok": False, "error": "Phone number not found"}, 401)
            if hashlib.sha256(str(data.get("password") or "").encode("utf-8")).hexdigest() != profile.get("passwordHash"):
                return self._send_json({"ok": False, "error": "Wrong password"}, 401)
            return self._send_json({"ok": True, "profile": public_profile(profile)})


        if path == "/api/customers":
            try:
                data = json.loads(self._read_body().decode("utf-8"))
            except ValueError:
                return self._send_json({"ok": False, "error": "bad json"}, 400)
            name = (data.get("name") or "").strip()
            if not name:
                return self._send_json({"ok": False, "error": "name required"}, 400)
            kind = data.get("kind") if data.get("kind") in ("office", "regular") else "regular"
            with LOCK:
                customers = get_customers()
                customer = {"id": next_customer_id(customers), "name": name,
                            "phone": (data.get("phone") or "").strip(),
                            "kind": kind, "createdAt": int(time.time() * 1000)}
                customers.append(customer)
                save_customers(customers)
            return self._send_json({"ok": True, "customer": customer})

        m = re.match(r"^/api/customers/([^/]+)/pay$", path)
        if m:
            cid = m.group(1)
            try:
                body = json.loads(self._read_body().decode("utf-8"))
            except ValueError:
                body = {}
            with LOCK:
                customers = get_customers()
                if not any(str(c.get("id")) == cid for c in customers):
                    return self._send_json({"ok": False, "error": "customer not found"}, 404)
                jobs = get_jobs()
                n = 0
                for job in jobs:
                    if job.get("customerId") == cid and not job.get("paid"):
                        job["paid"] = True
                        if body.get("note"):
                            job["paidNote"] = body["note"]
                        n += 1
                save_jobs(jobs)
            return self._send_json({"ok": True, "customerId": cid, "paid": n})

        if path == "/api/settings":
            try:
                data = json.loads(self._read_body().decode("utf-8"))
            except ValueError:
                return self._send_json({"ok": False, "error": "bad json"}, 400)
            with LOCK:
                cur = get_settings()
                old_url = cur.get("updateUrl")
                cur.update(data)
                save_json(SETTINGS_FILE, cur)
            # The owner changed the release channel — check it right away
            # instead of waiting for the next 6-hour cycle.
            if data.get("updateUrl") and data.get("updateUrl") != old_url:
                threading.Thread(target=fetch_update_info, daemon=True).start()
            return self._send_json({"ok": True})

        if path == "/api/clear-history":
            # Deletes job RECORDS only (name, token, amount, payment,
            # date/time). Files are NOT deleted by this — they delete
            # as per the delete-hours setting (the cleanup thread sweeps
            # any file left without a record once it passes that time).
            with LOCK:
                jobs = get_jobs()
                n = len(jobs)
                save_jobs([])
            return self._send_json({"ok": True, "cleared": n})

        if path == "/api/machine-health/refresh":
            # Poll both machines right now (SNMP timeouts are short,
            # so this answers within seconds) and return fresh health.
            # The two polls run in parallel — a dead printer must not
            # make the other machine wait.
            threads = [threading.Thread(target=poll_machine, args=(n,), daemon=True)
                       for n in (1, 2)]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=15)
            return self._send_json(machine_health_payload())

        if path == "/api/apply-update":
            # Silent self-update, applied right now instead of at the
            # next start. The server stops, the new code is applied and
            # a new process takes over (with rollback if it fails).
            marker = _load_pending_marker()
            if not marker or not _pending_is_valid(marker):
                return self._send_json({"ok": False, "error": "update not downloaded yet"}, 400)
            threading.Thread(target=do_update_now, daemon=False).start()
            return self._send_json({"ok": True, "applying": True, "version": str(marker["version"])})

        if path == "/api/dismiss-update-note":
            try:
                os.remove(LAST_UPDATE_FILE)
            except OSError:
                pass
            return self._send_json({"ok": True})

        if path == "/api/update":
            with update_info_lock:
                info = dict(update_info)
            dl = (info.get("download_url") or "").strip()
            if not dl:
                return self._send_json({"ok": False, "error": "no update available"}, 400)
            try:
                upd_dir = os.path.join(BASE, "update")
                os.makedirs(upd_dir, exist_ok=True)
                dest = os.path.join(upd_dir, "Printzo-Setup-new.exe")
                req = urllib.request.Request(dl, headers={"User-Agent": "Printzo/" + VERSION})
                with urllib.request.urlopen(req, timeout=60) as resp, open(dest, "wb") as f:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        f.write(chunk)
            except Exception as e:
                return self._send_json({"ok": False, "error": "download failed: %s" % e}, 502)
            # Launch the new installer detached. It stops this old server
            # itself (PID file) before installing, so the tool restarts
            # with the new version. A launch failure is reported, never
            # allowed to crash the server.
            launched = False
            launch_error = ""
            try:
                subprocess.Popen(
                    [dest], start_new_session=True,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL, close_fds=True)
                launched = True
            except Exception as e:
                launch_error = str(e)
            return self._send_json({
                "ok": True, "downloaded": True, "launched": launched,
                "path": dest, "error": launch_error or None})

        if path == "/api/jobs":
            ctype = self.headers.get("Content-Type", "")
            m = re.search(r"boundary=(.+)", ctype)
            if not m:
                return self._send_json({"ok": False, "error": "multipart expected"}, 400)
            body = self._read_body()
            parts, files = parse_multipart(body, m.group(1).encode())
            try:
                meta = json.loads(parts.get("meta", "{}"))
            except ValueError:
                return self._send_json({"ok": False, "error": "bad meta"}, 400)
            if "file" not in files:
                return self._send_json({"ok": False, "error": "no file"}, 400)
            fname, data = files["file"]
            with LOCK:
                settings = get_settings()
                token = settings.get("nextToken", 101)
                settings["nextToken"] = token + 1
                save_json(SETTINGS_FILE, settings)
                job_id = "S%d" % int(time.time() * 1000)
                stored = "%s_%s" % (job_id, safe_filename(fname))
                with open(os.path.join(JOBS_DIR, stored), "wb") as f:
                    f.write(data)
                job = dict(meta)
                job.update({"id": job_id, "token": token, "stored": stored,
                            "fileName": fname, "size": len(data)})
                # Billing: which customer (if any) this job belongs to, and
                # how it is paid. Walk-in customers keep Cash/UPI only —
                # credit is assigned by the owner (job card / WhatsApp
                # form), never by the customer self-service page.
                job["customerId"] = meta.get("customerId") or None
                job["paymentMode"] = meta.get("paymentMode") or meta.get("pay") or "cash"
                if job["paymentMode"] == "credit":
                    job["paid"] = False
                # Multi-machine auto-assign: the client sends machine 0
                # to mean "Auto — least busy". Only the server sees
                # every job from every source (web, WhatsApp), so it
                # resolves the machine here. Waiting = jobs still to
                # print (pending or approved). Tie goes to Machine 1.
                jobs = get_jobs()
                # NB: machine 0 means Auto — do NOT write
                # `int(meta.get("machine") or 1)` here: 0 is falsy in
                # Python, so `0 or 1` is 1 and Auto would never trigger.
                raw_m = meta.get("machine")
                try:
                    m = int(raw_m) if raw_m is not None else 1
                except (TypeError, ValueError):
                    m = 1
                if m == 0:
                    waiting = {1: 0, 2: 0}
                    for j in jobs:
                        if j.get("status") in ("pending", "approved"):
                            jm = j.get("machine") or 1
                            if jm in waiting:
                                waiting[jm] += 1
                    m = 1 if waiting[1] <= waiting[2] else 2
                elif m not in (1, 2):
                    m = 1
                job["machine"] = m
                jobs.append(job)
                save_jobs(jobs)
            return self._send_json({"ok": True, "job": job})

        m = re.match(r"^/api/jobs/([^/]+)/status$", path)
        if m:
            job_id = m.group(1)
            try:
                patch = json.loads(self._read_body().decode("utf-8"))
            except ValueError:
                return self._send_json({"ok": False, "error": "bad json"}, 400)
            with LOCK:
                jobs = get_jobs()
                job = next((j for j in jobs if str(j.get("id")) == job_id), None)
                if not job:
                    return self._send_json({"ok": False, "error": "not found"}, 404)
                for k in ("status", "paid", "note", "machine", "customerId", "paymentMode"):
                    if k in patch:
                        job[k] = patch[k]
                # Assigning credit means "pay later" — the job is unpaid
                # until the owner marks it paid (per job, or via bill pay).
                if patch.get("paymentMode") == "credit":
                    job["paid"] = False
                save_jobs(jobs)
            return self._send_json({"ok": True, "job": job})

        return self._send_json({"ok": False, "error": "not found"}, 404)


def lan_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith("127."))


def bind_with_retry():
    """Bind port 8000, retrying for up to 10 seconds if the port is
    briefly busy (e.g. the old server is still shutting down after an
    update). If something already answers on the port, it is a running
    copy — return None so the caller just opens the browser instead
    of starting a second server."""
    last_err = None
    for _ in range(11):
        try:
            return ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
        except OSError as e:
            last_err = e
            try:
                with urllib.request.urlopen("http://127.0.0.1:8000/", timeout=1) as resp:
                    if resp.status == 200:
                        return None
            except Exception:
                pass
            time.sleep(1)
    try:
        with urllib.request.urlopen("http://127.0.0.1:8000/", timeout=1) as resp:
            if resp.status == 200:
                return None
    except Exception:
        pass
    raise last_err


if __name__ == "__main__":
    open_browser = "--open-browser" in sys.argv
    # Silent self-update: if a new version was downloaded earlier,
    # apply it now, before serving anything. A spawned process takes
    # over (new version, or the rolled-back old one) and this process
    # exits; if the apply cannot even start, serve the old version
    # in this process as before.
    _marker = _load_pending_marker()
    if _marker and _pending_is_valid(_marker):
        if perform_update_flow(_marker):
            sys.exit(0)
    try:
        server = bind_with_retry()
    except OSError as e:
        print("Printzo could not start (port %d busy): %s" % (PORT, e))
        sys.exit(1)
    if server is None:
        # Another copy is already running — just open it.
        if open_browser:
            webbrowser.open("http://localhost:%d" % PORT)
        sys.exit(0)
    SERVER = server
    print("Printzo running! Open one of these addresses in a browser")
    print("on the same WiFi (no internet needed):")
    for ip in lan_ips() or ["<your-pc-ip>"]:
        print("  http://%s:%d" % (ip, PORT))
    print("Owner PIN (default): 1234 — change it in Settings.")
    print("Version: %s — Press Ctrl+C to stop." % VERSION)
    threading.Thread(target=cleanup_old_files, daemon=True).start()
    threading.Thread(target=update_check_loop, daemon=True).start()
    threading.Thread(target=health_poll_loop, daemon=True).start()
    write_pid()
    atexit.register(remove_pid)
    if open_browser:
        threading.Timer(1.5, lambda: webbrowser.open("http://localhost:%d" % PORT)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
